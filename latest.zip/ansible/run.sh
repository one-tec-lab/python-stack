#!/bin/bash

/usr/local/bin/ansible-playbook /app/main.yml
